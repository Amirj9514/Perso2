import { Component } from '@angular/core';

@Component({
  selector: 'app-projections',
  standalone: true,
  imports: [],
  templateUrl: './projections.component.html',
  styleUrl: './projections.component.scss'
})
export class ProjectionsComponent {

}
