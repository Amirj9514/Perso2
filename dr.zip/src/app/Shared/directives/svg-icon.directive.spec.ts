import { SvgIconDirective } from './svg-icon.directive';

describe('SvgIconDirective', () => {
  it('should create an instance', () => {
    const directive = new SvgIconDirective();
    expect(directive).toBeTruthy();
  });
});
