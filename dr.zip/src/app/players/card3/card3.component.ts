import { Component } from '@angular/core';

@Component({
  selector: 'app-card3',
  standalone: true,
  imports: [],
  templateUrl: './card3.component.html',
  styleUrl: './card3.component.scss'
})
export class Card3Component {

}
