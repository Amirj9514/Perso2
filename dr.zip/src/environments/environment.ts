export const environment = {
    production:true,
    apiUrl: 'https://sportsdataapi.onrender.com/',
};
