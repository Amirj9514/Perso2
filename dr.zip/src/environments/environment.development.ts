export const environment = {
    apiUrl: 'https://sportsdataapi.onrender.com/',
};
